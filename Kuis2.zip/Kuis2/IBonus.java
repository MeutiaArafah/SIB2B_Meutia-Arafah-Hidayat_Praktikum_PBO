package Kuis2;

public interface IBonus {
    void tampilkanBonus();
}
