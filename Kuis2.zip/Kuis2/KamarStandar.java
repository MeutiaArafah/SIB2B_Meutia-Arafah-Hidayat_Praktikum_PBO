package Kuis2;

public class KamarStandar extends Kamar{
    
    public KamarStandar(String jenis, double harga, int kapasitas){
        super(jenis, harga, kapasitas);
    }

    public void hitungHargaTotal(int malam){
        double total = harga * malam;
        System.out.println("Total Harga (" + malam + " malam): " + total);
    }
}

// public abstract class Kamar {
//     public String jenis;
//     public double harga; 
//     public int kapasitas;

//     public void tampilkanInfo(){
//         System.out.println("=== DETAIL KAMAR ===");
//         System.out.println("Jenis Kamar : " + jenis);
//         System.out.println("Harga       : " + harga);
//         System.out.println("Kapasitas   : " + kapasitas);
//     }