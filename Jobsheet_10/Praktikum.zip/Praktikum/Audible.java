package Jobsheet_10.Praktikum;

public interface Audible {
    void naikkanVolume(int increment);
    void turunkanVolume(int decrement);
}
